"use client"
import "bootstrap/dist/css/bootstrap.min.css";
import Wrapper from "@/component/wrapper/Wrapper";
import bootstap from  'bootstrap/dist/js/bootstrap.bundle.min.js';

import axios from "axios";
import { useEffect } from "react";


export default function RootLayout({ children }) {

  useEffect(() => {
    bootstap
  }, []);

  return (
    <html lang="en">
      <body suppressHydrationWarning>
        <Wrapper>{children}</Wrapper>
      </body>
    </html>
  );
}
