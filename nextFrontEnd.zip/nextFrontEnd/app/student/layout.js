"use client";

import {
  asyncSigninStudent,
  asyncSignoutStudent,
  fetchCurrentStudent,
} from "@/store/Actions/studentActions";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

export default function studentLayout({ children }) {
  const [studentData, setStudentData] = useState({});
  const [signData, setsignData] = useState({});

  const dispatch = useDispatch();

  // const fetchedStudent = useSelector(state => state.studentReducer.student);
  const {student , isAuthenticated} = useSelector(state => state.studentReducer);
  // useEffect(() => {
  //   dispatch(fetchCurrentStudent());
  // }, []);
  console.log(isAuthenticated)

  const router =useRouter()
  useEffect(() => {
    const getStudent = async () => {
      try {
        dispatch(fetchCurrentStudent());
      } catch (error) {
        console.error('Error fetching student data:', error);
      }
    };

    getStudent();
  }, []);

  useEffect(() => {
    if (student ) {
      setStudentData(student);
    }
    
  }, [student]);

  useEffect(() => {
    if (isAuthenticated ) {
      router.push("/student/auth")
    }else{

      router.push("/student")
    }

  }, [isAuthenticated]);

  const logoutHandler = () => {
    dispatch(asyncSignoutStudent());
    window.location.reload()
  };


  
  const onchangeSigninHandler = (e) => {
    setsignData({ ...signData, [e.target.name]: e.target.value });
    console.log(signData);
  };

  const signinHandler =async (event) => {
    event.preventDefault();
 await dispatch(asyncSigninStudent(signData));
 window.location.reload()

  };

// console.log("student",studentData)
  return (
    <>
      <nav className="navbar navbar-expand-lg bg-body-tertiary px-5 sticky-top shadow-sm p-2 mb-3 bg-body-tertiary rounded">
        <div className="container-fluid d-flex justify-content-between">
          <Link className="navbar-brand" href="/">
            <img
              style={{ width: "100px" }}
              src="https://internshala.com//static/images/internshala_og_image.jpg"
              alt=""
            />
          </Link>
          {/* <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button> */}
          <div
            className="collapse navbar-collapse ms-md-5"
            id="navbarSupportedContent"
          >
            <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <a className="nav-link active" aria-current="page" href="#">
                  Internship
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#">
                  Jobs
                </a>
              </li>

              <li className="nav-item dropdown">
                <a
                  className="nav-link dropdown-toggle"
                  href="#"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                 {studentData.firstName}
                </a>
                <ul className="dropdown-menu px-3">
                  <li>
                   <p className="fw-bold m-0">
                  {`${studentData.firstName}  ${studentData.lastName}` }

                   </p >
                  
                    <p className="fw-semibold m-0">{studentData.email}</p>
                  </li>
                  <hr className="dropdown-divider" />

                  <li>
                    <a className="dropdown-item" href="#">
                      Another action
                    </a>
                  </li>
                  <li>
                  </li>
                  <li>
                    <a className="dropdown-item" href="#">
                      Something else here
                    </a>
                  </li>
                </ul>
              </li>
              <li className="nav-item">
                <button className="btn btn-danger" onClick={logoutHandler}>
                Logout

                </button>
                {/* <a className="nav-link btn btn-danger" onClick={logoutHandler}>
                </a> */}
              </li>
            </ul>
          </div>
        </div>
      </nav>
      {children}
      <div
          className="modal fade p-4"
          id="exampleModal"
          tabindex="-1"
          aria-labelledby="exampleModalLabel"
          aria-hidden="true"
        >
          <div className="modal-dialog p-5">
            <div className="modal-content">
              <div className="modal-header">
                <h1 className="modal-title fs-5" id="exampleModalLabel">
                 Student
                </h1>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                ></button>
              </div>
              <form className="p-3" onSubmit={signinHandler}>
              <div className="row mb-3">
                <div className="mb-3">
                  <label
                    htmlFor="exampleFormControlInput1"
                    className="form-label"
                  >
                    Email address
                  </label>
                  <input
                    name="email"
                    onChange={onchangeSigninHandler}
                    value={signData.email}
                    type="email"
                    className="form-control"
                    id="exampleFormControlInput1"
                    placeholder="name@example.com"
                  />
                </div>
                <div className="mb-2">
                  <label
                    htmlFor="exampleFormControlInput2"
                    className="form-label"
                  >
                    Enter Password
                  </label>
                  <input
                    name="password"
                    onChange={onchangeSigninHandler}
                    value={signData.password}
                    type="password"
                    className="form-control"
                    id="exampleFormControlInput2"
                    placeholder="password"
                  />
                </div>
              </div>
             
                <button type="submit" className="btn btn-primary " >
                 Signin
                </button>
              </form>
              <a className="text-end text-decoration-none text-primary p-4" href="">Forgot password ?</a>
             
            </div>
          </div>
        </div>
    </>
  );
}
