// import axios from "@/utils/axios";

// import {
//   addstudent,
//   removestudent,
//   iserror,
//   removeerror,
// } from "../Reducers/studentReducer";

// export const asynCurrentStudent = async (dispatch, getState) => {
//     try {
//         const { data } = await axios.get("/");
//         console.log(data)
//     } catch (error) {
//         console.log(error)
        
//     }

// };

import axios from "@/utils/axios";
import {
  addstudent,
  removestudent,
  iserror,
  removeerror,
} from "../Reducers/studentReducer";

// Define your asynchronous action creator using Redux Thunk
export const fetchCurrentStudent = () => async (dispatch, getState) => {
  try {
    const { data } = await axios.post("/student");
    // console.log(data.student);
    dispatch(addstudent(data.student))
  } catch (error) {
    dispatch(iserror(error.response.data.message))
    console.log(error.response.data.message);
  }
};
export const asyncSignupStudent = (student) => async (dispatch, getState) => {
  try {
    const { data } = await axios.post("/student/signup",student);
    fetchCurrentStudent()
    console.log(data);
  } catch (error) {
    dispatch(iserror(error.response.data.message))

    console.log(error.response.data.message);
    // Dispatch your error action (e.g., iserror) here if needed
  }
};

export const asyncSigninStudent = (student) => async (dispatch, getState) => {
  try {
    const { data } = await axios.post("/student/signin",student);
    fetchCurrentStudent()
    console.log(data);
  } catch (error) {
    dispatch(iserror(error.response.data.message))

    console.log(error.response.data.message);
    // Dispatch your error action (e.g., iserror) here if needed
  }
};


export const asyncSignoutStudent = (student) => async (dispatch, getState) => {
  try {
    const { data } = await axios.get("/student/signout",student);
    dispatch(removestudent(data))
    // fetchCurrentStudent()
    // console.log(data);
  } catch (error) {
    dispatch(iserror(error.response.data.message))

    console.log(error.response.data.message);
    // Dispatch your error action (e.g., iserror) here if needed
  }
};

