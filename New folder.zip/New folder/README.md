step 1-
make next app ,remove  global.css,module.css, install bootstrap,import bootstrap  inside layout.js fiile ,  remove intial code inside page.js file and make new component using rafce command 
------
import "bootstrap/dist/css/bootstrap.min.css"
-----

step 2-readux toolkit ,context api ko use krne k liye pure commponent ko wrap krna pdta hai or layout ko "use client " banan pdta hai ,to fir layout front mai show hota hai ,pr esa nhi krte hai wrap krne k liye ek new component folder k and ek file bna lete hai  component/wrapper/wrapper.js bna lete hai 

